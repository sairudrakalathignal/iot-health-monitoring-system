#include <WiFi.h>
#include <HTTPClient.h>
#include <Wire.h>
#include "RTClib.h" // For DS3231, optional


// ------------------- WiFi / ThingSpeak -------------------
const char* ssid = "Supp";
const char* password = "duhhhhhh";
const char* thingSpeakWriteAPIKey = "Y2RAMEPROX4RGO8V";
const char* thingSpeakServer = "http://api.thingspeak.com/update";


// ------------------- Pins -------------------
const int pillboxPin = 35; // Pushbutton input
const int cupPin = 34; // Potentiometer / tilt ADC
const int ledPin = 18; // Reminder LED
const int buzzerPin = 19; // Buzzer


// ------------------- Variables -------------------
RTC_DS3231 rtc; // optional
int pillboxState = HIGH;
int lastPillboxState = HIGH;
unsigned long lastDebounceTime = 0;
unsigned long debounceDelay = 50;
int cupThreshold = 600; // adjust based on pot calibrationS
bool medicationTaken = false;


// ------------------- Setup -------------------
void setup() {
Serial.begin(115200);


pinMode(pillboxPin, INPUT_PULLUP);
pinMode(ledPin, OUTPUT);
pinMode(buzzerPin, OUTPUT);


WiFi.begin(ssid, password);
Serial.print("Connecting to WiFi");
while (WiFi.status() != WL_CONNECTED) {
delay(500);
Serial.print(".");
}
Serial.println("Connected!");


// Initialize RTC if used
if (!rtc.begin()) {
Serial.println("Couldn't find RTC");
}
}


// ------------------- Loop -------------------
void loop() {
// Simulate scheduled medication time: call checkMedication()
checkMedication();
delay(500); // main loop delay
}


// ------------------- Functions -------------------
void checkMedication() {
// Turn on LED + Buzzer as reminder
digitalWrite(ledPin, HIGH);
}