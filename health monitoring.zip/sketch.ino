#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// ADC pins (wipers)
const int TEMP_PIN = 34;
const int BP_PIN   = 35;
const int ECG_PIN  = 32;
const int SPO2_PIN = 33;
const int BUTTON_PIN = 23;

void setup() {
  Serial.begin(115200);
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("SSD1306 allocation failed"));
    for (;;);
  }
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0,0);
  display.println("Patient Monitor Init...");
  display.display();
  delay(1500);
  display.clearDisplay();
}

void loop() {
  // ---- Read sensors ----
  int tempRaw = analogRead(TEMP_PIN);
  int bpRaw   = analogRead(BP_PIN);
  int ecgRaw  = analogRead(ECG_PIN);
  int spo2Raw = analogRead(SPO2_PIN);
  bool emergency = (digitalRead(BUTTON_PIN) == LOW);

  // ---- Apply formulas ----
  float temperature = ((tempRaw / 4095.0) * 3.3) * 100.0;              // °C
  float bp = map(bpRaw, 0, 4095, 60, 180);                             // mmHg
  float ecg = ((ecgRaw / 4095.0) * 3.3) * 0.02;                        // small mV scale
  float spo2 = (((spo2Raw / 4095.0) * 3.3) / 3.3) * 20 + 80;           // 80–100%

  // ---- Serial Output ----
  Serial.printf("Temp: %.1f C, BP: %.0f mmHg, ECG: %.2f mV, SpO2: %.1f%%  Emergency:%d\n",
                temperature, bp, ecg, spo2, emergency);

  // ---- Display on OLED ----
  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("Patient Monitor");
  display.printf("Temp: %.1f C\n", temperature);
  display.printf("BP: %.0f mmHg\n", bp);
  display.printf("SpO2: %.1f %%\n", spo2);

  // Optional: show alert message on OLED
  if (temperature > 38.0) {
    display.println("⚠ High Temp!");
  }
  if (bp > 140) {
    display.println("⚠ High BP!");
  }
  if (spo2 < 90) {
    display.println("⚠ Low SpO2!");
  }
  if (emergency) {
    display.println("🚨 EMERGENCY!");
  }
  display.display();

  // ---- Alerts in Serial Monitor ----
  if (temperature > 38.0) Serial.println("ALERT: High temperature!");
  if (bp > 140) Serial.println("ALERT: High blood pressure!");
  if (spo2 < 90) Serial.println("ALERT: Low oxygen level!");
  if (emergency) Serial.println("ALERT: Emergency button pressed!");

  delay(3000); // 3 seconds for testing; use 30000 (30s) for final demo
}